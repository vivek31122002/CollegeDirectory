package com.vivek.collegeDirectory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vivek.collegeDirectory.model.Students;
import com.vivek.collegeDirectory.repository.StudentsRepository;

@Service
public class StudentsService {

    @Autowired
    private StudentsRepository studentsRepository;

    public Students getStudentsById(Long id){
        return studentsRepository.findById(id).orElse(null);
    }

    public List<Students> getAllStudents(){
        return studentsRepository.findAll();
    }

}
