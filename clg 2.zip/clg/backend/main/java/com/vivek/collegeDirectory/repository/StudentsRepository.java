package com.vivek.collegeDirectory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vivek.collegeDirectory.model.Students;

public interface StudentsRepository extends JpaRepository<Students,Long>{
    
}
