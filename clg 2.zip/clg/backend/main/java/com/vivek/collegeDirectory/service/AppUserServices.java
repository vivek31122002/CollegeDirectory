package com.vivek.collegeDirectory.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vivek.collegeDirectory.model.AppUser;
import com.vivek.collegeDirectory.repository.UserRepository;

@Service
public class AppUserServices {
    
    
    @Autowired
    private UserRepository userRepository;

    public AppUser authenticate(String username, String password) {
        return userRepository.findByUsernameAndPassword(username, password).orElse(null);
    }

    public AppUser addUser(AppUser users){
        return userRepository.save(users);
    }

    public AppUser getUserById(Long id){
        return userRepository.findById(id).orElse(null);
    }
}
