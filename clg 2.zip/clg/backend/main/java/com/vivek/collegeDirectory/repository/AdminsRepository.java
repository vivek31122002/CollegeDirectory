package com.vivek.collegeDirectory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vivek.collegeDirectory.model.Admins;

public interface AdminsRepository extends JpaRepository<Admins,Long>{
    
}
