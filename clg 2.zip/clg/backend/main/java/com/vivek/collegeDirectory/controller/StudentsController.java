package com.vivek.collegeDirectory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vivek.collegeDirectory.model.Students;
import com.vivek.collegeDirectory.service.StudentsService;

@RestController
@RequestMapping("/api/students")
public class StudentsController {
    @Autowired
    private StudentsService studentsService;

    @GetMapping("/{id}")
    public Students getStudent(@PathVariable Long id){
        return studentsService.getStudentsById(id);
    }

    @GetMapping
    public List<Students> getAllStud(){
        return studentsService.getAllStudents();
    }
}
