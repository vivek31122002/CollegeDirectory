package com.vivek.collegeDirectory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vivek.collegeDirectory.model.Admins;
import com.vivek.collegeDirectory.model.Students;
import com.vivek.collegeDirectory.repository.AdminsRepository;
import com.vivek.collegeDirectory.repository.StudentsRepository;

@Service
public class AdminsService {

    @Autowired
    private AdminsRepository adminsRepository;

    @Autowired
    private StudentsRepository studentsRepository;

    public Admins addAdmins(Admins admins){
        return adminsRepository.save(admins);
    }

    public Admins getAdminById(Long id){
        return adminsRepository.findById(id).orElse(null);
    }

    public List<Admins> getAllAdmins(){
        return adminsRepository.findAll();
    }

    public Students addStudents(Students students){
        return studentsRepository.save(students);
    }

    public Students getStudentById(Long id){
        return studentsRepository.findById(id).orElse(null);
    }

    public List<Students> getAllStudents(){
        return studentsRepository.findAll();
    }
}
