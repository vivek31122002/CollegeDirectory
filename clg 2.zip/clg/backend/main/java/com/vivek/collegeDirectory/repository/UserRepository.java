package com.vivek.collegeDirectory.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vivek.collegeDirectory.model.AppUser;

public interface UserRepository extends JpaRepository<AppUser,Long>{
    Optional<AppUser> findByUsernameAndPassword(String username, String password);
}
