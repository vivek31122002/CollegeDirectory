package com.vivek.collegeDirectory.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vivek.collegeDirectory.model.AppUser;
import com.vivek.collegeDirectory.service.AppUserServices;


@RestController
@RequestMapping("/api/auth")
@CrossOrigin
public class UserController {

    @Autowired
    private AppUserServices authService;

    @PostMapping("/login")
    public String login(@RequestBody AppUser user) {
        AppUser authenticatedUser = authService.authenticate(user.getUsername(), user.getPassword());
        if (authenticatedUser == null) {
            return "Invalid credentials";
        }
        return authenticatedUser.getRole();
    }
}
