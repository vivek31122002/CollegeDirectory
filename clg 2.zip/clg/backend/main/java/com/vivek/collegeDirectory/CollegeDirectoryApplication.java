package com.vivek.collegeDirectory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeDirectoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeDirectoryApplication.class, args);
	}
}
