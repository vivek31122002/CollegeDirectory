import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function AdminDashboard() {

  const [users, setUsers] = useState([])
  useEffect(() => {
    loadUsers();
  }, [])
  const loadUsers = async () => {
    const result = await axios.get("http://localhost:8080/api/admin/all/students")
    setUsers(result.data)
  }
  return (
    <div className='container'>
      <div className='py-4'>
        <h1>Students List</h1>
        <Link className='btn btn-outline-dark mx-2' to='/addUser'>Add Student</Link>
        <button className='btn btn-outline-dark mx-2'>Faculty List</button>
        <button className='btn btn-outline-dark mx-2'>Admin List</button><div><br></br></div>
        <table className="table border shadow">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Phone</th>
              <th scope="col">Year</th>
              <th scope="col">Img</th>
              <th scope="col">Dept_id</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {
              users.map((user, index) => (
                <tr>
                  <th scope="row" key={index}>{index+1}</th>
                  <td>{user.name}</td>
                  <td>{user.email}</td>
                  <td>{user.phone}</td>
                  <td>{user.yearOfStudy}</td>
                  <td>{user.ImgURL}</td>
                  <td>{user.dept_id}</td>
                  <td>
                    <button className='btn btn-primary mx-2'>View</button>
                    <button className='btn btn-outline-primary mx-2'>Edit</button>
                    <button className='btn btn-danger mx-2'>Delete</button>
                  </td>
                </tr>
              ))
            }
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default AdminDashboard;
