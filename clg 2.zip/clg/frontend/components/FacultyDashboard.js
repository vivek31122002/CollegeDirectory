import React from 'react';

function FacultyDashboard() {
  return <h1>Welcome, Faculty Member!</h1>;
}

export default FacultyDashboard;
