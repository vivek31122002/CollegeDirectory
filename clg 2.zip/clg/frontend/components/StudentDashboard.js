import React from 'react';

function StudentDashboard() {
  return <h1>Welcome, Student!</h1>;
}

export default StudentDashboard;
