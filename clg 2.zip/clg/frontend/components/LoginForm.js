import React, { useState } from 'react';
import axios from 'axios';

function LoginForm({ setRole }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [userRole, setUserRole] = useState('student');
  const [error, setError] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8080/api/auth/login', {
        username,
        password,
        role: userRole,
      });
      if (response.data === 'Invalid credentials') {
        setError(response.data);
      } else {
        setRole(response.data);
      }
    } catch (err) {
      setError('Error logging in');
    }
  };

  return (
    <form onSubmit={handleLogin}>
      <h2>Login</h2>
      <label>Username:</label>
      <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
      <label>Password:</label>
      <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <label>Role:</label>
      <select value={userRole} onChange={(e) => setUserRole(e.target.value)}>
        <option value="student">Student</option>
        <option value="Faculty Member">Faculty Member</option>
        <option value="admin">Administrator</option>
      </select>
      <button type="submit">Login</button>
      {error && <p>{error}</p>}
    </form>
  );
}

export default LoginForm;
