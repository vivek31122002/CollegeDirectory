import React from 'react';
import LoginForm from './components/LoginForm';
import StudentDashboard from './components/StudentDashboard';
import FacultyDashboard from './components/FacultyDashboard';
import AdminDashboard from './components/AdminDashboard';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import AddStudentsByAdmin from './adminOperations/AddStudentsByAdmin';

function App() {
  const [role, setRole] = React.useState(null);

  return (
    <div>
      <Router>
        <Routes>
          <Route
            path="/"
            element={
              !role ? (
                <LoginForm setRole={setRole} />
              ) : role === "student" ? (
                <StudentDashboard />
              ) : role === "faculty" ? (
                <FacultyDashboard />
              ) : (
                <AdminDashboard />
              )
            }
          />
          <Route path="/addUser" element={<AddStudentsByAdmin />} />
          <Route path="/viewStudent"></Route>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
